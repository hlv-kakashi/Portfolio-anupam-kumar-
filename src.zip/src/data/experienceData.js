export const experienceData = [
    {
        id: 1,
        company: 'Steel Authority Of India Limited',
        jobtitle: 'Project Internship',
        startYear: '8 JULY-2019 ',
        endYear: '7 AUGUST-2019'
    },
  
]