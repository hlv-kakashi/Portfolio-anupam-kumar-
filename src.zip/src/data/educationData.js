export const educationData = [
    {
        id: 1,
        institution: 'Masai School',
        course: 'Full-Stack web Devlopment',
        startYear: "DEC 2021 ",
        endYear: " Aug 2022"
    },

    {  id: 2,
        institution: 'Birsa Institute of Technology',
        course: 'Bachelor of Technology',
        startYear: '2017 ',
        endYear: ' 2021',
     
    },
    {
        id: 3,
        institution: 'Chinmaya Vidyalaya',
        course: 'Higher Secondary Education',
        startYear: '2014 ',
        endYear: ' 2016'
    },
    {
        id:4,
        institution: "M.G.M.H.S school",
        course: "Matriculation",
        startYear: "2013 ",
        endYear: " 2014",
    }
    
]