export const socialsData = {
    github: 'https://github.com/hlv-kakashi',
    linkedIn: 'https://www.linkedin.com/in/anupam-kumar-490489218/',
    instagram: 'https://www.instagram.com/',
    medium: 'https://medium.com/@anupamkumar827009',
    youtube: 'https://youtube.com/'
}