export const aboutData = {
    title: "Who I am",
    description1: "My name's Anupam Kumar. I'm a full-stack web-developer based in Masai School, Benguluru.",
    description2:"An aspiring full-stack web-developer with a specialization in MERN stack. Passionate about making  a positive impact on clients, co-workers, and the Internet using skills to develop attractive and compelling websites . Seeking a challenging position in a reputable organization to expand and utilize  learnings, skills and knowledge.",
   
    image: 2
}