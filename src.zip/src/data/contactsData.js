export const contactsData = {
    email: 'anupamkumar827009@gmail.com',
    phone: '7903179655',
    address: 'Bokaro Jharkhand ',

    sheetAPI: ''
}