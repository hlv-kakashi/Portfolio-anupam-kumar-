export const blogData = [
  {
    id: 1,
    title: "Making of Bath & body works website clone",
    description:
      "It is a clone of an American retail store chain which sells soaps, lotions, fragrances, and candles.",
    image:
      "https://media3.giphy.com/media/fvqVax5PXIPm4i45Zw/giphy.gif?cid=ecf05e47jiv5zlorewb4dwihsu3iw4ojx2l1ip7g9rqpshvx&rid=giphy.gif&ct=g",
    url: "https://medium.com/@anupamkumar827009/bath-body-works-afe9072f50d3    ",
  },
  {
    id: 2,
    title: "Making of Big Basket clone",
    description: "An online Portal for buying grocery in India. ",
    date: "Feb 11, 2022",
    image:
      "https://media0.giphy.com/media/xTiTnizXXPe0x9uJjO/giphy.gif?cid=ecf05e47088c4fvdy6jkckz5g5yqe8xgnsht39zlcl21j2k1&rid=giphy.gif&ct=g",
    url: "https://medium.com/@anupamkumar827009/how-to-make-a-project-successful-within-a-given-time-frame-actually-before-time-428d6a780095",
  },
  {
    id: 3,
    title: "The start of my journey at Masai School",
    description:
      "I completed my B-tech degree in 2021 with no job in hand, started preparation for government jobs but had to quit due to lack of discipline and guidance",
    date: "Jan 06, 2022",
    image:
      "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBw0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ8PDg0NFREWFhURFhUZHDQgGB0lGxcWIT0hJSsrOi4uFx8/ODUsOTQvLisBCgoKDg0NFRAQFS8iIB0tLTIyLC0tLSsrNS8vLTctKystLTItLSstLS0tKy4tKy0uKzIuKy8vKy0rKzcrKzErLf/AABEIAIEBhQMBIgACEQEDEQH/xAAcAAEBAAIDAQEAAAAAAAAAAAAAAQQHAwUGAgj/xABFEAACAgIBAwIDAwYLBAsAAAAAAQIDBBESBRMhBjEHQVEUImEyNXF0gbMVJTM0UnKEkaG0wiOxssEWJCZCU2JzdZLw8f/EABoBAQEBAQEBAQAAAAAAAAAAAAIBAAMFBgT/xAApEQEBAAICAQMDAwUBAAAAAAAAAQIRAyESBEFRMXHhE6GxFCIzwfAF/9oADAMBAAIRAxEAPwDXQAPOfcVAGChUBSFGhCgoVAAUagAMNQFIUKEKChUABRoQpChQAFGoAChUBSGGhCgo1AAUKgKQo0IUFCoACjUABgoQpCjRkKChUABRoQoKFQAGGoCgouwAB5b7yhCkKNCFBhqAAoVAUhQoQpCjQhQUagAKFQFIYKAAo1AAUKEKCjUIUFGoAChQhSFGhCgwVAAUagKQoUIUhRoAChUBSFGoCkMFAAUagAKFAAYdOxIUh5b72gAKFQFIUagKQoUABRqAAwVAUhRoQojFt6Sbb9kk23+woVAfU65R8yjKK+souK/xMldLy3X3Vi5Lq1y7ix7XXr68ta0ULYwwN/My6el5dkO5Xi5U62tqyGPbKDX15JaKN6+rEIX/APP0MhRoDJxOn5F6cqMfIvivDlTTZYk/0xRw20zhPtzhOFi1uucJRn/8X5KDjB9yqnFblCcV9ZQkl/ifH/N6X4v6GEIZtvScyEHbPDy4Vpbdk8a6MEvrycdGEUPqAjevL8GbHpOZKPOOHlyhrfNY1zhr6746KNYRJPSb+i2fcIOXiKcmvdRTbX9xJwa8Si47XtKLW1+0o1s7L+EUq+myyftjeZXjvIlTwj9neocnUpe+9eOX1+SNXpnorvW3Vp4X8Hyy5PG7faa4Q7sqda7bs1ycdePq17vR50rjjMpvyoACrUABgqAAo0IUFCoQoKNQAFChCgo1AUGF2AAPLfeVAUhRoQoMFQAFGoAChQhSFGhCgo1D1Pwv/PvT/wCvf/l7Tyx6n4X/AJ86f/Xv/wAvYLH6x+f1H+LP7X+G8fUsMCMKszqLh2cGbug7U5QVrXGMuP8A3peXpafl/VIwOgev+mdRyPs1Ftkbnvtxurdfd0tvg/m9edPT8HnPjpN/YcOO/DzG2vq1TPX+9mq/Skmup9NabT+34flePe6KZ2yz1lp5XD6XHk4fK2++m9uo+kOlLMfVsiuuHZrnO2M1FY7mvP2icfZyS3+nw/dHD034k9IyciGNXfbGdklXVO2mddU5PwkpP23+KRxfF+bXRMhJ65W40ZfjHvRev8Efn6TaW02mvKa8NNezNll43pvT+nnPx7zyvXUbq+MvpmmzDl1OquMMnHlX35Rjp30Skofe17uLcXv6b/Z5b4Uei6+oznm5ceeJjz7ddL/JyL0k3y+sIprx82/omntD18+XROot+d4cpP8ATpM6/wCEHH+A8XXv3crn/W78/wDlxLZPJzx5ssfT3V99Mz1H626Z0hxx7ZSdiimsbFrUpVw+W1tRh+htHF0nrnRuvuvhqzIxLK8muu6HbyaZQmpKcX81tLfFtedP3NF+q3b/AAl1Dvcu79tyeXLe/wCUfH9nHWvw0Zvw7dq6107s75vISlr/AMHi+7v8OHInn2630mM4/KXvW21/jY/4m/tmN/qOH4Pem8enAq6hKEZ5eVzkrJJN01KbjGEP6O9bbXvv8Ecvxr/M39sxv9R434b/ABFq6dSsHNjN48ZzlRdUuUqeT5ShKHu48m3tefL8fRWzy7csMcsvT6x+XsOn/FjAuznizrtx6nOdcMy+cIV8o78zT/k09a2381vR434uY3SZSozenZGFO2yyVeVViX0z5fdco3OMH4fhpv58ke8eJ6Y65JuKwb77PvN1yePlyf1aXGb/AGo1v8TPQC6TBZWNZO3Dsk65Rs07MexpuKckvvRemtv2evfZMt6Xi8JnNbl+HuPhb6GpxsenqGVVGzMvhG2pWR2sWqS3HSftNrTb91vS+e8/qXxV6Pj3OlWX5HGTjO3HqU6ov56k5Ll+mOzufWjsXR+ofZt8/sN3b4b3w4eeOv8Ay7PzKvwLbrqDx4frW5ZV+nOhT6bmz/hXB7c7LK5Y9l9acJyXKMnC2PvyTUfyltJ/Rmq/jv8AnLE/UI/vrDM+Art7/UUt9js47l/R73KXH9vHl/cjD+O/5yxP1CP76w1u4mGPjza28rb/ADeX/ov/AIDoDZfQ/Sjs6Rn9RyYtV19MzJYkH47lix5auf4J+31fn5LetDhw42Td93s/+jz4cnJMcbvxmr90AB2ebQhSFGhCgoVAAUagKQwUIUhRoAChQAFF2AKQ8p97QhQUagAKFQFIUKEKQo0ABgqApCjQ9R8L/wA+dP8A69/+XtPLn1TbOuSnXOVc4/kzhJxlHxrw15XgUurty5MPLDLH5jcfx1/mWD+ty/dSNWel/wA5dO/X8L9/AxMnNvuSV191qT2lbbOaT+qTfg4IScWpRbjKLUoyi2nGS8pp/Jiyy3dvz8PBePi8N/LffxkX8S2/rGN+8NAWez/QzLvz8i2PCzIvsjtPjZdZOO17PTejGLll5XY+n4P0sPG3fb9Ieu1/EfUP1Kf/AAo1p8JfWVWBKzBzJqvGvs7tN0nqFNzSUlN/KMkl5+TXn32vB29RyZxcJ5OROElpwlfbKLX0ab0zFFc+9uGHpJjx5YZXe36J9UegundVmsizuVXuMU8jGlFO2KX3eSacZePn76150fHRPTXSfT/CxSl38myvFruyJqd1s7JpRqrikkvLW9L2W29I0Ph9ZzcePDHzcuiH9CjJuqh/dGWjgyM2+2xW233W2x1xtstnOyLT2tSb2vPkvnPrpz/pM9eNz6bx+Na/ib+2Y3+ow/hzZ0jqnTYYluNh/bKaHj5EHTUr7IJcVdGWuT3HT5L2e/w3pq/PyLY8bci+2O0+Nl1k47+um9HBCTjJSi3GUXuMotxlF/VNezN597ael1x+G+9723V0j4RUY2bTkvOttrx7q76quzGFnOElKKlZy8raXtFb/A4vjX6ix1ifwZCcbMi22ud0YtPsVQfJcvpJvXj6b/Deq5+oupSjwl1HqEoa1xebkOOv0cjrDeU1qRJwZXOZZ5b03v8AC71pTm4tODkWRhnUQVUYzevtVUVqMo7/ACpcUk17+N/ovU/hJ0q+6VsJZWKpNuVOPOvtJt7fFTg3H9C8L5JGh/8A7+07KPqLqSjwXUeoKGtcVm5Cjr6a5F8vkcvT2ZW4Za2/RPQMPp3Tmul4fCFqrllTqUnO1x5Ri7bJe+22kt/JePC8aq+PX5wxv/b1++tNfU5V1cpTrttrnPfOcLZxnPb29yT2/P1PnIyLbWpW22WyS0pW2SsaX03J+xbl0mHBcc/Le36N6wv+zeT48fwFd/k2fm0ypdRyXFweTkuDjwcHkWuDhrXHjvWteNGKa3bcfH4b7CFIY6AAwVAUhRqApChQAFGoAChUABRoADC7EhQeW+8qAAo1AUhhoAChUABRqApChQhQUazs3pyqxsLI5uX2uGRJw46Vfbudet7871s7av0puPS28hcs7JxcfIrUU5Yf2lqVEn5+9yr5S149jrpdYUsWnFtxMe1Y8bo02ylkxsirJub/ACbFF+X80Z1nrTqEp2zlOtqdlVtdfbXbxrKrY2VSqXuuPHitt/db3sU0/LlOX2+b+P2T096ahm6c8h0r7c8SUlVz4xWPdc7Nb8/yWtficlPo+zjJ3XRq7WRkV3yUe5XHFqxY5DyINPc1KMlpeN7j5Rw1+qra5wlRi4mPGN1uROqqNzhbfOqVXOXOxtajOWoxaS2/DOPG9V5ldGNj/wCysrxZW8O7BzdlNlbrnj2efvV8XJa91vw/C0v7XPKc27ZX3hdDxsuThhZN9s+xmW/Z7cXjkOdNLsgkoSlGSm1x8PafyfuYvVeh2YdGHbkRuqnkyyedFlLrsrhVOCTSl5e1Lfy9j7XX3BONGHh48JU5dMo1xulKSvqdU5Oyybm9Rfhb0vozByM+dmPjYzjBQxXkSraT5SdsouXLzrxxWtJG6WTPc+P39/w7+Xo7i25ZUY0zc7sa7tOSt6dXR37cpxT2tRcIqK3ubktrTZxdM9OY+bKt4mVe6u92Mjv40YXUylTZZXNKM3GUZdqa900189o62jrd9csSUVX/ANTotxoxlDnC6iyy2VkLIt6kmrZx0teNfPyc9XqS2l0/ZMfGxIVXxyXXUrrFdaoOC7krZyk4qMpx4ppJTl8/JenO48mr25/TvpuObRG+VtsdzzouuilW2NY+NXdqCclylLnx1+COHN9Nzjm4mFTOUp5sKJ1rIq7FtPdnKKjdDb4tceXhvaafz0RepLIRVdGPjY1KqzKlTV33Hlk1Kuy1ynY5OXGMUvOlr2994uT1q+zJozNxryqI46V0E+VllKSjdPbac9KKfyevb3N0OuTyt9mXR0bEyrK6MHNnZfO+ulRysbsQthJvd1cozl92OtuMtPT8bfg+8XoeLlNrDy7rO1bjRu7+LGnlTbfGnv1ase0pTh92WnqS/FHA/UEoSjZi4uHhWq+vIduPXY5uyDbSj3JyVcNvzCKSfs/Hg+o+opQ/m+Jh4vO6i67sRvfedVishB87HwhzSfGHH2X0Wr0Nmft/pnVelse/IlTi5d0uzn42FlK/GhXKEbcjsK6vjY1NKXyfF+V+z6x/RcrH01xyOVebFd9xgnPDlJ2dvlHfmMu3LT8eYyX03if9K7Y2q2jGxMZvMpzrlUsiX2i6q3uQU3ZY2octvjHj/uPnA9W5ePfRfWqd0Yiw+3KMnVdSpzmua5flKUtpprTjH8d3pzs5fauXD9NV2KqqV2U8y7ErzO3i4FmVRj1WQ51q2UJdzynDzGD4817nWdK6fXbVkZGRbOnHxnRCaqrVt9l1rlwrhFyS9oWNtvwo/MzOn+pp0zxLniYd+ThRphj5N8b3NV1/kRlGNihLS8KTjtJLztJrB6d1SVCvrdVORRk8O9RcrOEpQk5QmpQkpRlFuWmn7Se9mXWXf/fd2HS+g42VmdqvOUcNURvty7KXCWPykq41ThvXLuThHxJrUtp/Iyei+kXkQn3pZcLodRfTZQxsRZMabFFcrLXzXGCbab/Awo+p8iuNscaGPhq3sRbxqnFqqpSUa9ybck3Nycpbk2l50kjmfrLM7it40c/tUcu37kuORZ9njRZGyPLTjOKbkvHmcta+V6c8pn7Jm+nY0YUcl/brnKm+zu42JGzBg68i2lKV/NaT7alvXtNHY5XoquGfDB5dSXK7Ir+0WdPjCm2NVFlm6X3P9o3wSS8e7PP5XVK7aKqLMLGk6KbKKL+eUraq5W2WpJK3i9SslrlF/LezNu9TuWY8+OFiVZc53zsthLLfcdtU65Jxla0vy2/CXlL5bTo2Zfz+GJ6g6QsN47jK7jk0yuVWVR9nyqUrJQ1ZXyek+O09+UzqjM6j1CeT2HaoOymiGP3UnzuhDag7POnJR1HfjxFbMMyyXXaApCpQhQUKhCgo1AAYKEKQo0IUFCoACi7EAHlPvagKQoUABRqAAo0IUhQoQoMFQAFGoCkKNCFBQqAAo1AAUKgKQwUABRqAAoUIUFGoACjUABQoQpGUaEKDBUABRqApChQhSFGgAKFQFIUagKQw6diCsh5b7yhCgo1AAYKEKQo0ABRqApChUBSFGgAKFQAGGoCkKFCFIUaAAoVAAUKEKQo0ABhqApChQhSFGgAKFQAFGoCkKFAAUagAMFQAFGhCgoVAAUXYkAPLfeUABhqAAoUABRqAAoUIwCjQhQYagAKFQAFChACiAgKFAAUagAMFGCAo1SMAoBCgo1AAUKgAKNCAFGhADBQAFCjIAUaMgBQoCAo0ABhf/9k=",

    url: "https://medium.com/@anupamkumar827009/the-start-of-my-journey-at-masai-school-cafed3480d29",
  },
];

// Do not remove any fields.
// Leave it blank instead as shown below.

/* 
{
    id: 1,
    title: 'Car Pooling System',
    description: '',
    date: 'Oct 1, 2020',
    image: '',
    url: 'https://preview.colorlib.com/theme/rezume/'
}, 
*/
